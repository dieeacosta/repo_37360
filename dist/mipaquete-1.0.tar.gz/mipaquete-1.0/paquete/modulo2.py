def funcion_modulo2():
    print("Hola, soy un módulo del paquete modulo2")